document.addEventListener('DOMContentLoaded', function() {
    const storiesContainer = document.getElementById('storiesContainer');

    function fetchAndDisplayStories() {
        storiesContainer.innerHTML = '<p class="loading-message">Loading stories...</p>';

        fetch('get_stories.php')
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`HTTP error! status: ${response.status} - ${text}`);
                    });
                }
                return response.json();
            })
            .then(stories => {
                storiesContainer.innerHTML = ''; 

                if (stories.length === 0) {
                    storiesContainer.innerHTML = '<p class="no-stories">No stories shared yet. Be the first!</p>';
                    return;
                }

                stories.forEach(story => {
                    const storyCard = document.createElement('div');
                    storyCard.classList.add('story-card');

                    const name = story.isAnonymous ? 'Anonymous' : story.name;
                    const email = story.email ? `<p><strong>Email:</strong> ${story.email}</p>` : '';
                    const ageRange = story.ageRange ? `<p><strong>Age Range:</strong> ${story.ageRange}</p>` : '';
                    const messageOfHope = story.messageOfHope ? `<p><strong>Message of Hope:</strong> ${story.messageOfHope}</p>` : '';
                    const submissionDate = story.submission_date ? `<p><strong>Date:</strong> ${new Date(story.submission_date).toLocaleDateString()}</p>` : '';

                    storyCard.innerHTML = `
                        <h4>${story.title}</h4>
                        <p><strong>Shared By:</strong> ${name}</p>
                        ${ageRange}
                        ${email}
                        <div class="story-content">
                            <p>${story.story}</p>
                        </div>
                        ${messageOfHope}
                        ${submissionDate}
                    `;
                    storiesContainer.appendChild(storyCard);
                });
            })
            .catch(error => {
                console.error('Error fetching stories:', error);
                storiesContainer.innerHTML = `<p class="no-stories">Failed to load stories: ${error.message}. Please try again later.</p>`;
            });
    }

    fetchAndDisplayStories();

    const currentPath = window.location.pathname;
    const currentPageFilename = currentPath.split('/').pop();

    const mainNavLinks = document.querySelectorAll('.main-nav-sticky ul li a');

    mainNavLinks.forEach(link => {
        const linkFilename = link.getAttribute('href').split('/').pop();

        link.classList.remove('active', 'active-page');
        link.removeAttribute('aria-current');

        if (linkFilename === currentPageFilename) {
            link.classList.add('active-page');
            link.setAttribute('aria-current', 'page');
        }
    });

    const languageSelect = document.getElementById('languageSelect');
    if (languageSelect) {
        languageSelect.addEventListener('change', function() {
            const selectedLanguage = this.value;
            console.log('Language changed to:', selectedLanguage);
        });
    }
});