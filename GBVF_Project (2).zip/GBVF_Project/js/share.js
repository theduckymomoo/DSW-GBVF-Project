document.addEventListener('DOMContentLoaded', function() {
    // --- Navigation Active State Logic ---
    const currentPath = window.location.pathname;
    const currentPageFilename = currentPath.split('/').pop();

    const mainNavLinks = document.querySelectorAll('.main-nav-sticky ul li a');

    mainNavLinks.forEach(link => {
        const linkFilename = link.getAttribute('href').split('/').pop();

        // Remove active classes and aria-current from all links first
        link.classList.remove('active', 'active-page');
        link.removeAttribute('aria-current');

        // Add active classes and aria-current to the current page's link
        if (linkFilename === currentPageFilename) {
            link.classList.add('active-page');
            link.setAttribute('aria-current', 'page');
        }
    });

    // --- Language Selector Logic ---
    const languageSelect = document.getElementById('languageSelect');
    if (languageSelect) {
        languageSelect.addEventListener('change', function() {
            const selectedLanguage = this.value;
            console.log('Language changed to:', selectedLanguage);
            // In a real application, you would implement your translation logic here.
            // This might involve:
            // 1. Loading a JSON file with translations for the selected language.
            // 2. Iterating through elements with 'data-translate' attributes and updating their text content.
        });
    }

    // --- Share Your Story Form Submission Logic ---
    const tellYourStoryForm = document.querySelector('.tell-your-story');
    if (tellYourStoryForm) {
        const submitButton = tellYourStoryForm.querySelector('button');

        submitButton.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Get form elements - CORRECTED SELECTORS
            const nameInput = tellYourStoryForm.querySelector('input[id="name"]'); // Corrected to id="name"
            const emailInput = tellYourStoryForm.querySelector('input[id="email"]'); // Corrected to id="email"
            const ageRangeSelect = tellYourStoryForm.querySelector('select[id="age-range"]'); // Explicit ID for age range
            const titleInput = tellYourStoryForm.querySelector('input[id="title"]');
            const storyTextarea = tellYourStoryForm.querySelector('textarea[id="story"]');
            const messageTextarea = tellYourStoryForm.querySelector('textarea[id="message"]');
            const anonymousCheckbox = tellYourStoryForm.querySelector('input[id="anonymous"]');
            const consentCheckbox = tellYourStoryForm.querySelector('input[id="consent"]');

            // Basic Client-Side Validation
            if (!storyTextarea.value.trim()) {
                alert('Please share your story. The story field cannot be empty.');
                storyTextarea.focus();
                return;
            }

            if (!consentCheckbox.checked) {
                alert('You must consent to having your story shared.');
                return;
            }

            // Collect Data
            const storyData = {
                name: nameInput.value.trim(),
                email: emailInput.value.trim(),
                ageRange: ageRangeSelect.value,
                title: titleInput.value.trim(),
                story: storyTextarea.value.trim(),
                messageOfHope: messageTextarea.value.trim(),
                isAnonymous: anonymousCheckbox.checked,
                consentGiven: consentCheckbox.checked
            };

            console.log('Submitting Story Data:', storyData);

            // --- Send this data to your backend server ---
            fetch('submit_story.php', { // THIS IS THE CRUCIAL CHANGE: Correct path to PHP script
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(storyData)
            })
            .then(response => {
                if (!response.ok) {
                    // If the server response is not OK, try to read it as text for better debugging
                    return response.text().then(text => {
                        throw new Error(`HTTP error! status: ${response.status} - ${text}`);
                    });
                }
                return response.json(); // Parse the JSON response from the server
            })
            .then(data => {
                console.log('Server response:', data);
                if (data.success) {
                    alert('Thank you for sharing your story! It has been submitted successfully.');
                    tellYourStoryForm.reset(); // Clear the form on success
                } else {
                    alert('There was an error submitting your story: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error submitting story:', error);
                alert('There was a network or server error submitting your story. Please try again later. Details: ' + error.message);
            });
        });
    }
});