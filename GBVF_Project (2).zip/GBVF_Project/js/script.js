const translations = {};
let originalTextsLoaded = false;

function loadOriginalTexts() {
    if (originalTextsLoaded) return;
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (element.innerText !== undefined && element.innerText.trim() !== '') {
            translations[key] = element.innerText;
        } else if (element.hasAttribute('placeholder')) {
            translations[key] = element.getAttribute('placeholder');
        } else if (element.hasAttribute('title')) {
            translations[key] = element.getAttribute('title');
        }
    });
    originalTextsLoaded = true;
}

async function translatePage() {
    const languageSelect = document.getElementById("languageSelect");

    if (!languageSelect) {
        console.warn("Element with ID 'languageSelect' not found. Translation functionality may not work as expected.");
        return;
    }

    const targetLang = languageSelect.value;
    
    if (targetLang === 'en') {
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[key]) {
                if (element.innerText !== undefined) {
                    element.innerText = translations[key];
                } else if (element.hasAttribute('placeholder')) {
                    element.setAttribute('placeholder', translations[key]);
                } else if (element.hasAttribute('title')) {
                    element.setAttribute('title', translations[key]);
                }
            }
        });
        console.log("Page restored to English.");
        return;
    }

    const elementsToTranslate = document.querySelectorAll('[data-translate]');
    const translatePromises = [];

    elementsToTranslate.forEach(element => {
        const key = element.getAttribute('data-translate');
        const originalText = translations[key] || element.innerText;

        if (originalText.trim() === "") {
            console.log(`Element with data-translate='${key}' is empty, skipping translation.`);
            return;
        }

        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${targetLang}&dt=t&q=${encodeURIComponent(originalText)}`;
        
        translatePromises.push(
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data && data[0] && data[0][0] && data[0][0][0]) {
                        const translatedText = data[0][0][0];
                        if (element.innerText !== undefined) {
                            element.innerText = translatedText;
                        } else if (element.hasAttribute('placeholder')) {
                            element.setAttribute('placeholder', translatedText);
                        } else if (element.hasAttribute('title')) {
                            element.setAttribute('title', translatedText);
                        }
                    } else {
                        console.warn(`No valid translation found for key '${key}'.`);
                    }
                })
                .catch(error => console.error(`Translation error for key '${key}':`, error))
        );
    });

    await Promise.allSettled(translatePromises);
    console.log(`All elements processed for translation to ${targetLang}.`);
}

document.addEventListener("DOMContentLoaded", function () {
    const profileIcon = document.getElementById("profileIcon");
    const profileDropdown = document.getElementById("profileDropdown");

    loadOriginalTexts();


    if (profileIcon && profileDropdown) {
        profileIcon.addEventListener("click", function(event) {
            event.stopPropagation();
            profileDropdown.classList.toggle("show");
        });

        document.addEventListener("click", function(event) {
            if (profileDropdown.classList.contains("show") && !profileDropdown.contains(event.target) && event.target !== profileIcon) {
                profileDropdown.classList.remove("show");
            }
        });

        profileDropdown.querySelectorAll('a').forEach(item => {
            item.addEventListener('click', function(event) {
                profileDropdown.classList.remove('show');
            });
        });
    } else {
        console.warn("Profile icon or dropdown not found.");
    }

    const emergencyBtn = document.getElementById("emergencyBtn");
    if (emergencyBtn) {
        emergencyBtn.addEventListener("click", function() {
            sendSilentAlert();
            window.open("https://www.google.com/search?q=weather", "_blank");
        });
    }

    function sendSilentAlert() {
        console.log("Attempting to send silent alert...");

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;
                    const timestamp = new Date().toISOString();

                    console.log(`User coordinates: Latitude ${latitude}, Longitude ${longitude}`);
                    console.log(`Timestamp: ${timestamp}`);

                    fetch('/api/send-alert', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            latitude: latitude,
                            longitude: longitude,
                            timestamp: timestamp,
                        })
                    })
                    .then(response => {
                        if (!response.ok) {
                            console.error(`Silent alert failed to send to server: HTTP status ${response.status}`);
                        } else {
                            console.log("Silent alert successfully sent to server (simulated).");
                        }
                    })
                    .catch(error => {
                        console.error("Error sending silent alert to server:", error);
                    });
                },
                (error) => {
                    console.error("Error getting user location for silent alert:", error);
                    console.log("Attempting to send silent alert without coordinates due to location error.");
                    fetch('/api/send-alert', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            latitude: null,
                            longitude: null,
                            timestamp: new Date().toISOString(),
                        })
                    })
                    .then(response => {
                        if (!response.ok) {
                            console.error(`Silent alert (no coords) failed to send to server: HTTP status ${response.status}`);
                        } else {
                            console.log("Silent alert (no coords) successfully sent to server (simulated).");
                        }
                    })
                    .catch(error => {
                        console.error("Error sending silent alert (no coords) to server:", error);
                    });
                },
                { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
            );
        } else {
            console.warn("Geolocation is not supported by this browser. Sending silent alert without coordinates.");
            fetch('/api/send-alert', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    latitude: null,
                    longitude: null,
                    timestamp: new Date().toISOString(),
                })
            })
            .then(response => {
                if (!response.ok) {
                    console.error(`Silent alert (no geolocation) failed to send to server: HTTP status ${response.status}`);
                } else {
                    console.log("Silent alert (no geolocation) successfully sent to server (simulated).");
                }
            })
            .catch(error => {
                console.error("Error sending silent alert (no geolocation) to server:", error);
            });
        }
    }


    const storyButton = document.getElementById("Story");
    if (storyButton) {
        storyButton.addEventListener("click", function() {
            window.location.href = "legal.html"; 
        });
    }

    const learnButton = document.getElementById("Learn");
    if (learnButton) {
        learnButton.addEventListener("click", function() {
            window.location.href = "finalChat.html"; 
        });
    }

    window.addEventListener('scroll', function() {
    const backgroundImage = document.querySelector('.background-image img');
    const scrollPosition = window.pageYOffset;
    backgroundImage.style.transform = 'translateY(' + scrollPosition * 0.5 + 'px)';
    });

    window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    });
});