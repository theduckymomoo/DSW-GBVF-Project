<?php
header('Content-Type: application/json');

$folderPath = 'Stories/';
$stories = [];

if (is_dir($folderPath)) {
    $files = glob($folderPath . '*.txt');

    array_multisort(
        array_map('filemtime', $files),
        SORT_DESC,
        $files
    );

    foreach ($files as $filePath) {
        $content = file_get_contents($filePath);
        $storyData = [
            'submission_date' => '',
            'name' => 'Anonymous',
            'email' => 'N/A',
            'ageRange' => 'Not specified',
            'title' => 'No Title',
            'isAnonymous' => false, 
            'consentGiven' => 'No',
            'story' => '',
            'messageOfHope' => 'N/A'
        ];

        $inStoryBlock = false;
        $inMessageOfHopeBlock = false;

        $lines = explode("\n", $content);
        foreach ($lines as $line) {
            $line = trim($line);

            if (empty($line)) {
                continue;
            }

            if (strpos($line, 'Timestamp:') === 0) {
                $storyData['submission_date'] = trim(str_replace('Timestamp:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Name:') === 0) {
                $storyData['name'] = trim(str_replace('Name:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Email:') === 0) {
                $storyData['email'] = trim(str_replace('Email:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Age Range:') === 0) {
                $storyData['ageRange'] = trim(str_replace('Age Range:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Title:') === 0) {
                $storyData['title'] = trim(str_replace('Title:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Is Anonymous:') === 0) {
                $storyData['isAnonymous'] = (trim(str_replace('Is Anonymous:', '', $line)) === 'Yes');
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, 'Consent Given:') === 0) {
                $storyData['consentGiven'] = trim(str_replace('Consent Given:', '', $line));
                $inStoryBlock = false; $inMessageOfHopeBlock = false;
            } elseif (strpos($line, '--- Story ---') === 0) {
                $storyData['story'] = '';
                $inStoryBlock = true;
                $inMessageOfHopeBlock = false;
            } elseif (strpos($line, '--- Message of Hope ---') === 0) {
                $storyData['messageOfHope'] = '';
                $inMessageOfHopeBlock = true;
                $inStoryBlock = false;
            } elseif ($inStoryBlock) {
                $storyData['story'] .= $line . "\n";
            } elseif ($inMessageOfHopeBlock) {
                $storyData['messageOfHope'] .= $line . "\n";
            }
        }
        $storyData['story'] = trim($storyData['story']);
        $storyData['messageOfHope'] = trim($storyData['messageOfHope']);

        $stories[] = $storyData;
    }
}

echo json_encode($stories);
?>